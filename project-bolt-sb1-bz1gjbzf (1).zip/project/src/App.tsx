import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { 
  Shield, 
  AlertTriangle, 
  MapPin, 
  Phone, 
  Bell, 
  UserCircle,
  ChevronDown,
  Activity,
  Users,
  AlertCircle,
  Navigation,
  Camera,
  Radio,
  Eye,
  Map,
  Send,
  Compass,
  AlertOctagon,
  FileQuestion,
  ArrowRight,
  Mail,
  Calendar,
  Building,
  Edit,
  Save,
  Plus,
  X,
  Volume2
} from 'lucide-react';
import { VoiceSOS } from './components/VoiceSOS';

// Fix Leaflet icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Component to handle map recenter
function RecenterMap({ lat, lng }: { lat: number; lng: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView([lat, lng], 13);
  }, [lat, lng, map]);
  return null;
}

interface AdminDetails {
  name: string;
  age: number;
  location: string;
  role: string;
  email: string;
  joinedDate: string;
  trustedContacts: {
    name: string;
    relation: string;
    phone: string;
  }[];
}

interface SituationAssessment {
  situation: string;
  situationDetails: string;
  sourceLocation: string;
  destinationLocation: string;
  feelingSafe: 'yes' | 'no' | 'unsure';
  accompaniedBy: 'alone' | 'friend' | 'family' | 'colleague' | 'stranger';
  timeOfDay: string;
  environmentType: 'public' | 'private' | 'transit' | 'other';
  nearbyPeople: 'none' | 'few' | 'many';
  lightingCondition: 'well_lit' | 'dim' | 'dark';
  hasEscapeRoute: 'yes' | 'no' | 'unsure';
}

function App() {
  const [selectedView, setSelectedView] = useState('dashboard');
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [showAssessmentForm, setShowAssessmentForm] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [showRouteModal, setShowRouteModal] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<{
    from: { lat: number; lng: number };
    to: { lat: number; lng: number };
  } | null>(null);

  const [adminDetails, setAdminDetails] = useState<AdminDetails>({
    name: "",
    age: 0,
    location: "",
    role: "",
    email: "",
    joinedDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' }),
    trustedContacts: []
  });

  const [assessmentData, setAssessmentData] = useState<SituationAssessment>({
    situation: '',
    situationDetails: '',
    sourceLocation: '',
    destinationLocation: '',
    feelingSafe: 'unsure',
    accompaniedBy: 'alone',
    timeOfDay: new Date().toTimeString().split(' ')[0],
    environmentType: 'public',
    nearbyPeople: 'few',
    lightingCondition: 'well_lit',
    hasEscapeRoute: 'unsure'
  });

  const [newContact, setNewContact] = useState({
    name: '',
    relation: '',
    phone: ''
  });

  const [showAdminDetails, setShowAdminDetails] = useState(false);
  const [emergencyStatus, setEmergencyStatus] = useState({ sent: false, timestamp: null });

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          setLocationError("Unable to access location. Please enable location services.");
        }
      );
    } else {
      setLocationError("Geolocation is not supported by your browser.");
    }
  }, []);

  const handleSaveProfile = () => {
    setShowEditProfile(false);
  };

  const handleAddContact = () => {
    if (newContact.name && newContact.relation && newContact.phone) {
      setAdminDetails(prev => ({
        ...prev,
        trustedContacts: [...prev.trustedContacts, newContact]
      }));
      setNewContact({ name: '', relation: '', phone: '' });
      setShowAddContact(false);
    }
  };

  const handleRemoveContact = (index: number) => {
    setAdminDetails(prev => ({
      ...prev,
      trustedContacts: prev.trustedContacts.filter((_, i) => i !== index)
    }));
  };

  const getSafetyRecommendations = (data: SituationAssessment) => {
    const recommendations: string[] = [];

    if (data.feelingSafe === 'no' || data.feelingSafe === 'unsure') {
      recommendations.push('Trust your instincts. If something feels wrong, it probably is.');
    }

    if (data.accompaniedBy === 'alone' || data.accompaniedBy === 'stranger') {
      recommendations.push('Share your live location with trusted contacts.');
      recommendations.push('Stay in well-lit, populated areas.');
    }

    if (data.nearbyPeople === 'none') {
      recommendations.push('Move to a more populated area if possible.');
      recommendations.push('Keep emergency contacts on speed dial.');
    }

    if (data.lightingCondition === 'dark' || data.lightingCondition === 'dim') {
      recommendations.push('Use well-lit routes and avoid dark areas.');
    }

    if (data.hasEscapeRoute === 'no') {
      recommendations.push('Identify potential exit routes and safe spaces nearby.');
    }

    if (data.environmentType === 'transit') {
      recommendations.push('Sit near the driver or in a car with other passengers.');
      recommendations.push('Have your ride-sharing app open and share trip details.');
    }

    return recommendations;
  };

  const handleAssessmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Assessment Data:', assessmentData);
    setShowAssessmentForm(false);
  };

  const handleEmergencyAlert = () => {
    const timestamp = new Date().toISOString();
    setEmergencyStatus({ sent: true, timestamp });
    
    console.log("Emergency alert sent to trusted contacts and police department");
    
    setTimeout(() => {
      setShowEmergencyModal(false);
      setTimeout(() => setEmergencyStatus({ sent: false, timestamp: null }), 30000);
    }, 2000);
  };

  const handleEmergencyDetected = async (evidence: { 
    audio: Blob; 
    transcript: string; 
    confidence: number 
  }) => {
    setShowEmergencyModal(true);
    console.log('Emergency detected:', {
      transcript: evidence.transcript,
      confidence: evidence.confidence,
      location,
      timestamp: new Date().toISOString()
    });
    setTimeout(handleEmergencyAlert, 1000);
  };

  const safetyMetrics = {
    incidentReports: 157,
    activeCases: 23,
    safeZones: 45,
    registeredUsers: 1289
  };

  const recentIncidents = [
    { type: 'Harassment', location: 'Central Park', time: '2 hours ago', status: 'Active', aiConfidence: '89%' },
    { type: 'Stalking', location: 'Downtown Metro', time: '5 hours ago', status: 'Under Investigation', aiConfidence: '92%' },
    { type: 'Suspicious Activity', location: 'Shopping Mall', time: '1 day ago', status: 'Resolved', aiConfidence: '85%' }
  ];

  const safetyTips = [
    'Share your live location with trusted contacts',
    'Use well-lit and populated routes',
    'Keep emergency contacts easily accessible',
    'Trust your instincts and stay alert'
  ];

  const activeSurveillance = [
    { location: 'Main Street Camera 1', status: 'Active', threats: 0 },
    { location: 'Central Station Camera 3', status: 'Alert', threats: 2 },
    { location: 'Park Entrance Camera 2', status: 'Active', threats: 1 }
  ];

  const safeRoutes = [
    { 
      from: { name: 'Central Station', coords: [40.7128, -74.0060] },
      to: { name: 'Business District', coords: [40.7136, -74.0050] },
      risk: 'Low',
      time: '15 min'
    },
    {
      from: { name: 'Shopping Mall', coords: [40.7142, -74.0064] },
      to: { name: 'Residential Area', coords: [40.7150, -74.0055] },
      risk: 'Medium',
      time: '20 min'
    },
    {
      from: { name: 'University Campus', coords: [40.7135, -74.0070] },
      to: { name: 'Metro Station', coords: [40.7145, -74.0065] },
      risk: 'Low',
      time: '10 min'
    }
  ];

  const SituationAssessmentForm = ({ 
    data, 
    onChange, 
    onSubmit 
  }: { 
    data: SituationAssessment;
    onChange: (field: keyof SituationAssessment, value: string) => void;
    onSubmit: () => void;
  }) => {
    const recommendations = getSafetyRecommendations(data);

    return (
      <div className="space-y-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              What type of situation are you in?
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={data.situation}
              onChange={(e) => onChange('situation', e.target.value)}
            >
              <option value="">Select situation</option>
              <option value="following">Being followed</option>
              <option value="harassment">Harassment</option>
              <option value="unsafe_environment">Unsafe environment</option>
              <option value="suspicious_activity">Suspicious activity</option>
              <option value="transportation">Transportation issues</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Describe the situation in detail
            </label>
            <textarea
              className="w-full p-2 border rounded-md"
              rows={3}
              value={data.situationDetails}
              onChange={(e) => onChange('situationDetails', e.target.value)}
              placeholder="Please provide any relevant details about the situation..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Do you feel safe right now?
            </label>
            <div className="flex gap-4">
              {['yes', 'no', 'unsure'].map((option) => (
                <label key={option} className="flex items-center">
                  <input
                    type="radio"
                    name="feelingSafe"
                    value={option}
                    checked={data.feelingSafe === option}
                    onChange={(e) => onChange('feelingSafe', e.target.value as 'yes' | 'no' | 'unsure')}
                    className="mr-2"
                  />
                  {option.charAt(0).toUpperCase() + option.slice(1)}
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Who are you with?
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={data.accompaniedBy}
              onChange={(e) => onChange('accompaniedBy', e.target.value as 'alone' | 'friend' | 'family' | 'colleague' | 'stranger')}
            >
              <option value="alone">Alone</option>
              <option value="friend">With a friend</option>
              <option value="family">With family</option>
              <option value="colleague">With colleague</option>
              <option value="stranger">With stranger(s)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Type of environment
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={data.environmentType}
              onChange={(e) => onChange('environmentType', e.target.value as 'public' | 'private' | 'transit' | 'other')}
            >
              <option value="public">Public space</option>
              <option value="private">Private space</option>
              <option value="transit">Public transit</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Are there people nearby?
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={data.nearbyPeople}
              onChange={(e) => onChange('nearbyPeople', e.target.value as 'none' | 'few' | 'many')}
            >
              <option value="none">No one around</option>
              <option value="few">A few people</option>
              <option value="many">Many people</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Lighting conditions
            </label>
            <select
              className="w-full p-2 border rounded-md"
              value={data.lightingCondition}
              onChange={(e) => onChange('lightingCondition', e.target.value as 'well_lit' | 'dim' | 'dark')}
            >
              <option value="well_lit">Well lit</option>
              <option value="dim">Dim lighting</option>
              <option value="dark">Dark</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Do you have a clear escape route?
            </label>
            <div className="flex gap-4">
              {['yes', 'no', 'unsure'].map((option) => (
                <label key={option} className="flex items-center">
                  <input
                    type="radio"
                    name="hasEscapeRoute"
                    value={option}
                    checked={data.hasEscapeRoute === option}
                    onChange={(e) => onChange('hasEscapeRoute', e.target.value as 'yes' | 'no' | 'unsure')}
                    className="mr-2"
                  />
                  {option.charAt(0).toUpperCase() + option.slice(1)}
                </label>
              ))}
            </div>
          </div>
        </div>

        {recommendations.length > 0 && (
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h4 className="text-blue-800 font-medium mb-2">Safety Recommendations:</h4>
            <ul className="list-disc pl-5 space-y-1">
              {recommendations.map((rec, index) => (
                <li key={index} className="text-blue-700">{rec}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex gap-4 mt-6">
          <button
            onClick={onSubmit}
            className="flex-1 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700"
          >
            Submit Report
          </button>
          <button
            onClick={() => setShowAssessmentForm(false)}
            className="flex-1 border border-gray-300 py-2 rounded-lg hover:bg-gray-50"
          >
            Cancel
          </button>
        </div>
      </div>
    );
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-gray-50"
    >
      {/* Navigation */}
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="bg-indigo-600 text-white p-4 sticky top-0 z-50"
      >
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
            >
              <Shield className="h-6 w-6" />
            </motion.div>
            <span className="text-xl font-bold">WomenSafe Analytics</span>
          </div>
          <div className="flex items-center space-x-4">
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowAssessmentForm(true)}
              className="bg-indigo-500 hover:bg-indigo-600 px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <FileQuestion className="h-5 w-5" />
              Report Situation
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowEmergencyModal(true)}
              className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <Radio className="h-5 w-5 animate-pulse" />
              Emergency Alert
            </motion.button>
            <motion.div whileHover={{ scale: 1.1 }}>
              <Bell className="h-5 w-5 cursor-pointer" />
            </motion.div>
            <div 
              className="flex items-center space-x-2 cursor-pointer"
              onClick={() => setShowAdminDetails(!showAdminDetails)}
            >
              <UserCircle className="h-5 w-5" />
              <span>{adminDetails.name || "Set Up Profile"}</span>
              <ChevronDown className="h-4 w-4" />
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Admin Details Dropdown */}
      <AnimatePresence>
        {showAdminDetails && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute right-4 top-16 bg-white rounded-lg shadow-lg z-50 w-80"
          >
            <div className="p-4">
              {!showEditProfile ? (
                <>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-indigo-100 p-3 rounded-full">
                        <UserCircle className="h-6 w-6 text-indigo-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-800">
                          {adminDetails.name || "Set Up Profile"}
                        </h3>
                        <p className="text-sm text-gray-500">{adminDetails.role || "Add Role"}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowEditProfile(true)}
                      className="text-indigo-600 hover:text-indigo-700"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar className="h-4 w-4" />
                      <span className="text-sm">Age: {adminDetails.age || "Not set"}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Building className="h-4 w-4" />
                      <span className="text-sm">{adminDetails.location || "Add location"}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Mail className="h-4 w-4" />
                      <span className="text-sm">{adminDetails.email || "Add email"}</span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <h3 className="font-semibold text-gray-800 mb-4">Edit Profile</h3>
                  <input
                    type="text"
                    placeholder="Name"
                    value={adminDetails.name}
                    onChange={(e) => setAdminDetails(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full p-2 border rounded"
                  />
                  <input
                    type="number"
                    placeholder="Age"
                    value={adminDetails.age || ''}
                    onChange={(e) => setAdminDetails(prev => ({ ...prev, age: parseInt(e.target.value) }))}
                    className="w-full p-2 border rounded"
                  />
                  <input
                    type="text"
                    placeholder="Location"
                    value={adminDetails.location}
                    onChange={(e) => setAdminDetails(prev => ({ ...prev, location: e.target.value }))}
                    className="w-full p-2 border rounded"
                  />
                  <input
                    type="email"
                    placeholder="Email"
                    value={adminDetails.email}
                    onChange={(e) => setAdminDetails(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full p-2 border rounded"
                  />
                  <input
                    type="text"
                    placeholder="Role"
                    value={adminDetails.role}
                    onChange={(e) => setAdminDetails(prev => ({ ...prev, role: e.target.value }))}
                    className="w-full p-2 border rounded"
                  />
                  <button
                    onClick={handleSaveProfile}
                    className="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700"
                  >
                    Save Profile
                  </button>
                </div>
              )}
              
              <div className="pt-4 border-t mt-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-semibold text-gray-700">Trusted Contacts</h4>
                  <button
                    onClick={() => setShowAddContact(true)}
                    className="text-indigo-600 hover:text-indigo-700"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <div className="space-y-2">
                  {adminDetails.trustedContacts.map((contact, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="text-sm">
                        <p className="font-medium text-gray-700">{contact.name}</p>
                        <p className="text-gray-500 text-xs">{contact.relation}</p>
                      </div>
                      <button
                        onClick={() => handleRemoveContact(index)}
                        className="text-red-500 hover:text-red-600"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Contact Modal */}
      <AnimatePresence>
        {showAddContact && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg p-6 max-w-md w-full"
            >
              <h3 className="text-xl font-semibold mb-4">Add Trusted Contact</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Contact Name"
                  value={newContact.name}
                  onChange={(e) => setNewContact(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full p-2 border rounded"
                />
                <input
                  type="text"
                  placeholder="Relation"
                  value={newContact.relation}
                  onChange={(e) => setNewContact(prev => ({ ...prev, relation: e.target.value }))}
                  className="w-full p-2 border rounded"
                />
                <input
                  type="tel"
                  placeholder="Phone Number"
                  value={newContact.phone}
                  onChange={(e) => setNewContact(prev => ({ ...prev, phone: e.target.value }))}
                  className="w-full p-2 border rounded"
                />
                <div className="flex gap-4">
                  <button
                    onClick={handleAddContact}
                    className="flex-1 bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700"
                  >
                    Add Contact
                  </button>
                  <button
                    onClick={() => setShowAddContact(false)}
                    className="flex-1 border border-gray-300 py-2 rounded hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Location Banner */}
      {(location || locationError) && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 ${locationError ? 'bg-red-50' : 'bg-green-50'}`}
        >
          <div className="container mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Compass className={`h-5 w-5 ${locationError ? 'text-red-500' : 'text-green-500'}`} />
              {locationError ? (
                <span className="text-red-700">{locationError}</span>
              ) : (
                <span className="text-green-700">
                  Location: {location?.lat.toFixed(6)}, {location?.lng.toFixed(6)}
                </span>
              )}
            </div>
            {!locationError && (
              <span className="text-green-600 text-sm">
                Real-time protection active
              </span>
            )}
          </div>
        </motion.div>
      )}

      {/* Emergency Alert Modal */}
      <AnimatePresence>
        {showEmergencyModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg p-6 max-w-md w-full"
            >
              {!emergencyStatus.sent ? (
                <>
                  <h2 className="text-2xl font-bold text-red-600 mb-4 flex items-center gap-2">
                    <AlertOctagon className="h-6 w-6" />
                    Emergency Alert
                  </h2>
                  <p className="text-gray-600 mb-4">
                    This will immediately notify:
                  </p>
                  <ul className="mb-6 space-y-2">
                    {adminDetails.trustedContacts.map((contact, index) => (
                      <li key={index} className="flex items-center gap-2 text-gray-700">
                        <Phone className="h-4 w-4 text-indigo-600" />
                        {contact.name} - {contact.relation}
                      </li>
                    ))}
                    <li className="flex items-center gap-2 text-gray-700">
                      <AlertCircle className="h-4 w-4 text-red-600" />
                      Local Police Department
                    </li>
                  </ul>
                  <div className="space-y-4">
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold flex items-center justify-center gap-2 hover:bg-red-700"
                      onClick={handleEmergencyAlert}
                    >
                      <Send className="h-5 w-5" />
                      Send Emergency Alert
                    </motion.button>
                    <motion.button 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-50"
                      onClick={() => setShowEmergencyModal(false)}
                    >
                      Cancel
                    </motion.button>
                  </div>
                </>
              ) : (
                <div className="text-center py-4">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
                  >
                    <Send className="h-8 w-8 text-green-600" />
                  </motion.div>
                  <h3 className="text-xl font-semibold text-green-600 mb-2">Alert Sent Successfully</h3>
                  <p className="text-gray-600">Emergency services and trusted contacts have been notified.</p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Assessment Form Modal */}
      <AnimatePresence>
        {showAssessmentForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">Situation Assessment</h2>
                <button
                  onClick={() => setShowAssessmentForm(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              
              <SituationAssessmentForm
                data={assessmentData}
                onChange={(field, value) => 
                  setAssessmentData(prev => ({ ...prev, [field]: value }))
                }
                onSubmit={handleAssessmentSubmit}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {/* Voice SOS System */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <VoiceSOS onEmergencyDetected={handleEmergencyDetected} />
        </motion.div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div whileHover={{ scale: 1.02 }} transition={{ type: "spring" }}>
            <MetricCard
              icon={<AlertTriangle className="h-8 w-8 text-red-500" />}
              title="Incident Reports"
              value={safetyMetrics.incidentReports}
              trend="+12% this month"
            />
          </motion.div>
          <motion.div whileHover={{ scale: 1.02 }} transition={{ type: "spring" }}>
            <MetricCard
              icon={<Activity className="h-8 w-8 text-yellow-500" />}
              title="Active Cases"
              value={safetyMetrics.activeCases}
              trend="5 resolved today"
            />
          </motion.div>
          <motion.div whileHover={{ scale: 1.02 }} transition={{ type: "spring" }}>
            <MetricCard
              icon={<MapPin className="h-8 w-8 text-green-500" />}
              title="Safe Zones"
              value={safetyMetrics.safeZones}
              trend="+3 new zones"
            />
          </motion.div>
          <motion.div whileHover={{ scale: 1.02 }} transition={{ type: "spring" }}>
            <MetricCard
              icon={<Users className="h-8 w-8 text-blue-500" />}
              title="Registered Users"
              value={safetyMetrics.registeredUsers}
              trend="+89 this week"
            />
          </motion.div>
        </div>

        {/* AI Surveillance Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 bg-white rounded-lg shadow-md p-6"
        >
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Eye className="h-6 w-6 text-purple-500" />
            AI Threat Detection
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {activeSurveillance.map((camera, index) => (
              <motion.div 
                key={index}
                whileHover={{ scale: 1.02 }}
                className="border rounded-lg p-4"
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <Camera className="h-5 w-5 text-gray-600" />
                    <span className="font-medium">{camera.location}</span>
                  </div>
                  <motion.span 
                    animate={{ scale: camera.threats > 0 ? [1, 1.1, 1] : 1 }}
                    transition={{ repeat: camera.threats > 0 ? Infinity : 0, duration: 2 }}
                    className={`px-2 py-1 rounded-full text-xs ${
                      camera.threats > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {camera.threats > 0 ? `${camera.threats} Threats Detected` : 'Clear'}
                  </motion.span>
                </div>
                <div className="h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                  <span className="text-gray-500">Live Feed</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Safe Routes Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 bg-white rounded-lg shadow-md p-6"
        >
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Navigation className="h-6 w-6 text-blue-500" />
            Safe Route Recommendations
          </h2>
          
          {/* Map Container */}
          <div className="h-96 mb-6 rounded-lg overflow-hidden">
            <MapContainer
              center={[40.7128, -74.0060]}
              zoom={13}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              {location && (
                <>
                  <Marker position={[location.lat, location.lng]}>
                    <Popup>Your current location</Popup>
                  </Marker>
                  <RecenterMap lat={location.lat} lng={location.lng} />
                </>
              )}
              {safeRoutes.map((route, index) => (
                <React.Fragment key={index}>
                  <Marker position={route.from.coords as [number, number]}>
                    <Popup>{route.from.name}</Popup>
                  </Marker>
                  <Marker position={route.to.coords as [number, number]}>
                    <Popup>{route.to.name}</Popup>
                  </Marker>
                </React.Fragment>
              ))}
            </MapContainer>
          </div>

          <div className="space-y-4">
            {safeRoutes.map((route, index) => (
              <motion.div 
                key={index}
                whileHover={{ scale: 1.01 }}
                className="border rounded-lg p-4 cursor-pointer"
                onClick={() => {
                  setSelectedRoute({
                    from: { lat: route.from.coords[0], lng: route.from.coords[1] },
                    to: { lat: route.to.coords[0], lng: route.to.coords[1] }
                  });
                  setShowRouteModal(true);
                }}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Map className="h-5 w-5 text-gray-600" />
                      <span className="font-medium">{route.from.name} → {route.to.name}</span>
                    </div>
                    <span className="text-sm text-gray-500">Estimated Time: {route.time}</span>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    route.risk === 'Low' ? 'bg-green-100 text-green-800' :
                    route.risk === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {route.risk} Risk
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}

function MetricCard({ icon, title, value, trend }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full">
      <div className="flex items-center justify-between mb-4">
        {icon}
        <span className="text-sm text-gray-500">{trend}</span>
      </div>
      <h3 className="text-gray-700 text-lg">{title}</h3>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  );
}

export default App;