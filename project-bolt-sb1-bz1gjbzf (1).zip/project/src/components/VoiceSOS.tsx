import React, { useEffect, useRef, useState } from 'react';
import RecordRTC from 'recordrtc';
import WaveSurfer from 'wavesurfer.js';
import { pipeline } from '@xenova/transformers';
import { Mic, MicOff, AlertTriangle, Volume2, Loader } from 'lucide-react';

interface VoiceSosProps {
  onEmergencyDetected: (evidence: { audio: Blob; transcript: string; confidence: number }) => void;
}

const DISTRESS_PHRASES = [
  'help',
  'emergency',
  'stop',
  'please help',
  'call police',
  'help me',
];

export function VoiceSOS({ onEmergencyDetected }: VoiceSosProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const [lastTranscript, setLastTranscript] = useState('');
  const [emergencyConfidence, setEmergencyConfidence] = useState(0);

  const recorderRef = useRef<RecordRTC | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const wavesurferRef = useRef<WaveSurfer | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const whisperPipelineRef = useRef<any>(null);

  useEffect(() => {
    // Initialize WaveSurfer
    wavesurferRef.current = WaveSurfer.create({
      container: '#waveform',
      waveColor: '#4f46e5',
      progressColor: '#818cf8',
      cursorColor: '#312e81',
      height: 40,
      normalize: true,
    });

    // Initialize Whisper pipeline
    const initWhisper = async () => {
      try {
        whisperPipelineRef.current = await pipeline('automatic-speech-recognition', 'Xenova/whisper-tiny.en');
      } catch (error) {
        console.error('Failed to initialize Whisper:', error);
      }
    };

    initWhisper();

    return () => {
      wavesurferRef.current?.destroy();
      stopRecording();
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // Set up audio analysis
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);

      // Configure recorder
      recorderRef.current = new RecordRTC(stream, {
        type: 'audio',
        mimeType: 'audio/webm',
        sampleRate: 44100,
        desiredSampRate: 16000,
        numberOfAudioChannels: 1,
        timeSlice: 1000,
        ondataavailable: analyzeAudioChunk,
      });

      recorderRef.current.startRecording();
      setIsRecording(true);

      // Start audio level monitoring
      monitorAudioLevel();
    } catch (error) {
      console.error('Error starting recording:', error);
    }
  };

  const stopRecording = () => {
    if (recorderRef.current) {
      recorderRef.current.stopRecording(() => {
        const blob = recorderRef.current?.getBlob();
        if (blob) {
          wavesurferRef.current?.loadBlob(blob);
        }
      });
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }

    if (audioContextRef.current) {
      audioContextRef.current.close();
    }

    setIsRecording(false);
  };

  const monitorAudioLevel = () => {
    if (!analyserRef.current || !isRecording) return;

    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);

    // Calculate average volume level
    const average = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
    const normalizedLevel = average / 255;
    setAudioLevel(normalizedLevel);

    // Check for sudden loud noises
    if (normalizedLevel > 0.8) {
      checkForEmergency(true);
    }

    requestAnimationFrame(monitorAudioLevel);
  };

  const analyzeAudioChunk = async (audioChunk: Blob) => {
    if (!whisperPipelineRef.current) return;

    try {
      setIsProcessing(true);
      const result = await whisperPipelineRef.current(audioChunk);
      const transcript = result.text.toLowerCase();
      setLastTranscript(transcript);

      // Check for distress phrases
      const containsDistressPhrase = DISTRESS_PHRASES.some(phrase => 
        transcript.includes(phrase.toLowerCase())
      );

      if (containsDistressPhrase) {
        checkForEmergency(false);
      }
    } catch (error) {
      console.error('Error analyzing audio:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const checkForEmergency = (isAudioTrigger: boolean) => {
    // Calculate confidence based on multiple factors
    let confidence = 0;

    if (isAudioTrigger) {
      confidence += 0.6; // High volume events
    }

    const hasDistressWord = DISTRESS_PHRASES.some(phrase => 
      lastTranscript.includes(phrase.toLowerCase())
    );

    if (hasDistressWord) {
      confidence += 0.4;
    }

    setEmergencyConfidence(confidence);

    // Trigger emergency if confidence is high enough
    if (confidence > 0.7) {
      recorderRef.current?.getBlob((blob: Blob) => {
        onEmergencyDetected({
          audio: blob,
          transcript: lastTranscript,
          confidence,
        });
      });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <Volume2 className="h-6 w-6 text-indigo-600" />
          Voice SOS Monitor
        </h2>
        <button
          onClick={isRecording ? stopRecording : startRecording}
          className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
            isRecording 
              ? 'bg-red-100 text-red-700 hover:bg-red-200'
              : 'bg-indigo-600 text-white hover:bg-indigo-700'
          }`}
        >
          {isRecording ? (
            <>
              <MicOff className="h-5 w-5" />
              Stop Recording
            </>
          ) : (
            <>
              <Mic className="h-5 w-5" />
              Start Recording
            </>
          )}
        </button>
      </div>

      <div className="space-y-4">
        {/* Audio Waveform */}
        <div id="waveform" className="w-full h-12 bg-gray-50 rounded-lg"></div>

        {/* Audio Level Indicator */}
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-600">Audio Level:</span>
          <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className="h-full bg-indigo-600 transition-all duration-300"
              style={{ width: `${audioLevel * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Processing Status */}
        {isProcessing && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Loader className="h-4 w-4 animate-spin" />
            Processing audio...
          </div>
        )}

        {/* Emergency Confidence */}
        {emergencyConfidence > 0 && (
          <div className="flex items-center gap-2 text-sm">
            <AlertTriangle className={`h-4 w-4 ${
              emergencyConfidence > 0.7 ? 'text-red-600' : 'text-yellow-600'
            }`} />
            <span>Emergency Confidence: {Math.round(emergencyConfidence * 100)}%</span>
          </div>
        )}

        {/* Last Transcript */}
        {lastTranscript && (
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">Last Transcript:</p>
            <p className="text-gray-800 mt-1">{lastTranscript}</p>
          </div>
        )}
      </div>
    </div>
  );
}